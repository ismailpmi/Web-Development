package feedback.service;

import java.util.List;

import feedback.dao.FeedBackDAO;
import feedback.exception.InvalidInputException;
import feedback.model.FeedBack;



public class FeedBackService {
	public List<FeedBack> findAll() {
		return FeedBackDAO.findAll();
	}
	public List<FeedBack> findStaffFeed() {
		return FeedBackDAO.findStaffFeed();
	}

	public FeedBack findById(FeedBack feedback) {
		
		if (feedback.getCode() == 0)
			try {
				throw new InvalidInputException("code is invalid");
			} catch (InvalidInputException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		else {
			FeedBackDAO.findById(feedback);
			
		}
		return feedback;
	}

	public void insert(FeedBack feedback) {
		try {
			if (feedback.getCode() < 0) {
				throw new InvalidInputException("Please enter valid code");
			}
			FeedBackDAO.insert(feedback);
		} catch (Exception e) {

			e.printStackTrace();
		}

	}
	public void insertStaffFeed(FeedBack feedback) {
		try {
			if (feedback.getCode() < 0) {
				throw new InvalidInputException("Please enter valid code");
			}
			FeedBackDAO.insertStaffFeed(feedback);
		} catch (Exception e) {

			e.printStackTrace();
		}

	}
	public void update(FeedBack feedback) {
		try {
			if (feedback.getCode() < 0||feedback.getName()==null) {
				throw new InvalidInputException("Please enter valid code");
			}
			FeedBackDAO.update(feedback);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void delete(FeedBack feedback) {
	
		try {
			if (feedback.getCode() < 0 ) {
				throw new InvalidInputException("Please enter valid code");
			}
			FeedBackDAO.delete(feedback);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
