package feedback.exception;

public class InvalidInputException extends Exception {

	public InvalidInputException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidInputException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}

}
