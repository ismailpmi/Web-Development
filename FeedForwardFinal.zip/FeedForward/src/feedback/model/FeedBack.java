package feedback.model;

public class FeedBack {

	int code;
	String user;
	String username;
	String password;
	String name;
	String email;
	int phone;
	String institude;
	String management;
	String comments;
	int rating;
	String course;
	String trainner;
	String syllabus_completion;
	String facility;
	public FeedBack(int code, String user, String username, String password, String name, String email, int phone,
			String institude, String management, String comments, int rating, String course, String trainner,
			String syllabus_completion, String facility) {
		super();
		this.code = code;
		this.user = user;
		this.username = username;
		this.password = password;
		this.name = name;
		this.email = email;
		this.phone = phone;
		this.institude = institude;
		this.management = management;
		this.comments = comments;
		this.rating = rating;
		this.course = course;
		this.trainner = trainner;
		this.syllabus_completion = syllabus_completion;
		this.facility = facility;
	}
	public FeedBack(int code, String user, String username, String name,String password, String email, int phone) {
		super();
		this.code = code;
		this.user = user;
		this.username = username;
		this.name = name;
		this.password = password;
		this.email = email;
		this.phone = phone;
	}
	
	public FeedBack(int code, String institude, String management, String comments, int rating) {
		super();
		this.code = code;
		this.institude = institude;
		this.management = management;
		this.comments = comments;
		this.rating = rating;
	}
	public FeedBack(int code, String comments, int rating, String course, String trainner, String syllabus_completion,
			String facility) {
		super();
		this.code = code;
		this.comments = comments;
		this.rating = rating;
		this.course = course;
		this.trainner = trainner;
		this.syllabus_completion = syllabus_completion;
		this.facility = facility;
	}
	public FeedBack(String username,String user,String password) {
		super();
		this.username = username;
		this.user= user;
		this.password = password;
	}
	public FeedBack() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getPhone() {
		return phone;
	}
	public void setPhone(int phone) {
		this.phone = phone;
	}
	public String getInstitude() {
		return institude;
	}
	public void setInstitude(String institude) {
		this.institude = institude;
	}
	public String getManagement() {
		return management;
	}
	public void setManagement(String management) {
		this.management = management;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	public String getTrainner() {
		return trainner;
	}
	public void setTrainner(String trainner) {
		this.trainner = trainner;
	}
	public String getSyllabus_completion() {
		return syllabus_completion;
	}
	public void setSyllabus_completion(String syllabus_completion) {
		this.syllabus_completion = syllabus_completion;
	}
	public String getFacility() {
		return facility;
	}
	public void setFacility(String facility) {
		this.facility = facility;
	}
	@Override
	public String toString() {
		return "FeedBack [code=" + code + ", user=" + user + ", username=" + username + ", password=" + password
				+ ", name=" + name + ", email=" + email + ", phone=" + phone + ", institude=" + institude
				+ ", management=" + management + ", comments=" + comments + ", rating=" + rating + ", course=" + course
				+ ", trainner=" + trainner + ", syllabus_completion=" + syllabus_completion + ", facility=" + facility
				+ "]";
	}
}
