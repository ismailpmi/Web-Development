package feedback.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import feedback.model.FeedBack;
import feedback.util.ConnectionUtil;





public class FeedBackDAO {

	public static List<FeedBack> findAll() {
		Connection con = ConnectionUtil.getConnection();
		ArrayList<FeedBack> feedbacklist = new ArrayList<>();
		PreparedStatement psmt;
		try {
			psmt = con.prepareStatement("Select code,user,username,name,password,email,phone from users;");
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				FeedBack feedBack = new FeedBack();
				feedBack.setCode(rs.getInt("code"));
				feedBack.setUser(rs.getString("user"));
				feedBack.setUsername(rs.getString("username"));
				feedBack.setName(rs.getString("name"));
				feedBack.setPassword(rs.getString("password"));
				feedBack.setEmail(rs.getString("email"));
				feedBack.setPhone(rs.getInt("phone"));
				

				feedbacklist.add(feedBack);
				System.out.println(""+rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+rs.getString(5)+" "+rs.getString(6)+""+rs.getInt(7));
			}
		} catch (Exception e) {
			System.out.println("Extraction error findAll");
		}
		return feedbacklist;
	}
	
	public static List<FeedBack> findStaffFeed() {
		Connection con = ConnectionUtil.getConnection();
		ArrayList<FeedBack> feedbacklist = new ArrayList<>();
		PreparedStatement psmt;
		try {
			psmt = con.prepareStatement("Select code,management,institude,rating,comments from staff;");
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				FeedBack feedBack = new FeedBack();
				feedBack.setCode(rs.getInt("code"));
				feedBack.setManagement(rs.getString("management"));
				feedBack.setInstitude(rs.getString("institude"));
				
				feedBack.setRating(rs.getInt("rating"));
				feedBack.setComments(rs.getString("comments"));

				feedbacklist.add(feedBack);
				System.out.println(""+rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getInt(4)+" "+rs.getString(5));
			}
		} catch (Exception e) {
			System.out.println("Extraction error findAll");
		}
		return feedbacklist;
	}
	public static List<FeedBack> findStudentFeed() {
		Connection con = ConnectionUtil.getConnection();
		ArrayList<FeedBack> feedbacklist = new ArrayList<>();
		PreparedStatement psmt;
		try {
			psmt = con.prepareStatement("Select code,course,trainner,facility,status,rating,comments from students;");
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				FeedBack feedBack = new FeedBack();
				feedBack.setCode(rs.getInt("code"));
				feedBack.setCourse(rs.getString("course"));
				feedBack.setTrainner(rs.getString("trainner"));
				feedBack.setFacility(rs.getString("facility"));
				feedBack.setSyllabus_completion(rs.getString("status"));
				feedBack.setRating(rs.getInt("rating"));
				feedBack.setComments(rs.getString("comments"));

				feedbacklist.add(feedBack);
				System.out.println(""+rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+rs.getString(5)+" "+rs.getInt(6)+" "+rs.getString(7));
			}
		} catch (Exception e) {
			System.out.println("Extraction error findAll");
		}
		return feedbacklist;
	}
//	public static FeedBack findById(FeedBack feedback) {
//		Connection con = ConnectionUtil.getConnection();
//		
//		PreparedStatement psmt,psmts;
//		try {
//			psmt = con.prepareStatement(
//				"Select user,username,password from users where password=?;");
//		
//			psmt.setInt(1, feedback.getCode());
//			ResultSet rs = psmt.executeQuery();
//			
//			while (rs.next()) {
//			
//				
//				feedback.setUser(rs.getString("user"));
//				feedback.setUsername(rs.getString("username"));
//				
//				feedback.setPassword(rs.getString("password"));
//				
//			}
//		} catch (Exception e) {
//			System.out.println("Extraction error findById");
//		}
//		return feedback;
//	}
	
	public static FeedBack findById(FeedBack feedback) {
		Connection con = ConnectionUtil.getConnection();
		
		PreparedStatement psmt,psmts;
		try {
////			psmt = con.prepareStatement(
////					"Select user,username,password,code,email,phone from signup where code=?;");
////			psmt.setInt(1, feedback.getCode());
////			ResultSet rs = psmt.executeQuery();
////			psmts = con.prepareStatement(
////					"Select rating,course from students where code=?;");
////			psmts.setInt(1, feedback.getCode());
////			ResultSet rs2 = psmts.executeQuery();
			psmt = con.prepareStatement(
					"SELECT a.code,a.user,a.username,a.name,a.password,a.email,a.phone,b.course,b.rating FROM users a, students b WHERE a.code = b.code;");
			psmt.setInt(1, feedback.getCode());
			ResultSet rs = psmt.executeQuery();
			
			while (rs.next()) {
			
				FeedBack feedBack = new FeedBack();
				feedBack.setCode(rs.getInt("code"));
				feedBack.setUser(rs.getString("user"));
				feedBack.setUsername(rs.getString("username"));
				feedBack.setName(rs.getString("name"));
				feedBack.setPassword(rs.getString("password"));
				feedBack.setEmail(rs.getString("email"));
				feedBack.setPhone(rs.getInt("phone"));
				feedBack.setCourse(rs.getString("course"));
				feedBack.setRating(rs.getInt("rating"));
			}
		} catch (Exception e) {
			System.out.println("Extraction error findById");
		}
		return feedback;
	}
	public static void insert(FeedBack feedback) {
		Connection con = ConnectionUtil.getConnection();
		PreparedStatement psmt;
		try {
			psmt = con.prepareStatement("INSERT INTO users(code,user,username,name,password,email,phone) VALUES(?,?,?,?,?,?,?);");
			psmt.setInt(1, feedback.getCode());
			psmt.setString(2, feedback.getUser());
			psmt.setString(3, feedback.getUsername());
			psmt.setString(4, feedback.getName());
			psmt.setString(5, feedback.getPassword());
			psmt.setString(6, feedback.getEmail());
			psmt.setInt(7, feedback.getPhone());
			
			int rows = psmt.executeUpdate();
			System.out.println("Rows affected :-" + rows);

		} catch (Exception e) {
			System.out.println("Update error");
		}
	}
	
	public static void update(FeedBack feedback) {
		Connection con = ConnectionUtil.getConnection();
		PreparedStatement psmt;
		try {
			psmt = con.prepareStatement("update users set name = ? where ID=?;");
			psmt.setString(1, feedback.getName());
		
			psmt.setInt(2, feedback.getCode());
			int rows = psmt.executeUpdate();
			System.out.println("Rows affected :-" + rows);

		} catch (Exception e) {
			System.out.println("Update error");
		}
	}

	public static void delete(FeedBack feedback) {
		Connection con = ConnectionUtil.getConnection();
		PreparedStatement psmt;
		try {
			psmt = con.prepareStatement("Delete from student where ID = ? ;");
			psmt.setInt(1, feedback.getCode());
			int rows = psmt.executeUpdate();
			System.out.println("Rows affected :-" + rows);

		} catch (Exception e) {
			System.out.println("Delete error");
		}

	}

	public static void insertStaffFeed(FeedBack feedback) {
		// TODO Auto-generated method stub
		Connection con = ConnectionUtil.getConnection();
		PreparedStatement psmt;
		try {
			psmt = con.prepareStatement("INSERT INTO staff(code,management,institude,rating,comments) VALUES(?,?,?,?,?);");
			psmt.setInt(1, feedback.getCode());
			psmt.setString(2, feedback.getManagement());
			psmt.setString(3, feedback.getInstitude());
			psmt.setInt(4, feedback.getRating());
			psmt.setString(5, feedback.getComments());
			
			
			int rows = psmt.executeUpdate();
			System.out.println("Rows affected :-" + rows);

		} catch (Exception e) {
			System.out.println("Update error");
		}
	}
	

}
