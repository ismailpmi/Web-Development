package feedback.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import feedback.model.FeedBack;
import feedback.service.FeedBackService;
import feedback.util.ConnectionUtil;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/Admin")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Connection connection = ConnectionUtil.getConnection();
		String username = request.getParameter("username");
//		String user = request.getParameter("user");
		String password = request.getParameter("password");
		
		
		String sql = "select * from users where username='" + username + "' and password='" + password + "'";
		PreparedStatement pst;
		try {
			if(username.equals("admin") && password.equals("admin")){
				 response.sendRedirect("Admin.html");
			}
			else{
			pst = connection.prepareStatement(sql);
			ResultSet rs= pst.executeQuery(sql);
	        if (rs.next()) {
	      if(rs.getString("user").equals("trainee")){
	            response.sendRedirect("Student_feed.html");
	      }
	      else if(rs.getString("user").equals("trainer")){
	    	  
	    		  response.sendRedirect("Staff_feed.html");
	    	  }
	      
	      else{
	    	  response.getWriter().print("User doesn't exists..Please register with your credentials");
				response.setContentType("text/html");
				RequestDispatcher rd = request.getRequestDispatcher("index.html");
				rd.include(request, response);
	      }
	        } else {
	        	
	        	response.getWriter().print("Invalid username/password");
				response.setContentType("text/html");
				RequestDispatcher rd = request.getRequestDispatcher("index.html");
				rd.include(request, response);
	            
	        }
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		

	}
}