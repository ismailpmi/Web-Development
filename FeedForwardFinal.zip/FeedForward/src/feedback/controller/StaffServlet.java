package feedback.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import feedback.dao.FeedBackDAO;
import feedback.model.FeedBack;
import feedback.service.FeedBackService;
import feedback.util.ConnectionUtil;

/**
 * Servlet implementation class StaffServlet
 */
@WebServlet("/StaffServlet")
public class StaffServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int code = Integer.parseInt(request.getParameter("code"));
		String management = request.getParameter("management");
		String institude = request.getParameter("institude");
		String comments = request.getParameter("comments");
		int rating = Integer.parseInt(request.getParameter("rating"));
		
		Connection con = ConnectionUtil.getConnection();
		PreparedStatement psmt;
		
			try {
				psmt = con.prepareStatement("INSERT INTO staff(code,management,institude,rating,comments) VALUES(?,?,?,?,?);");
			
			psmt.setInt(1, code);
			psmt.setString(2, management);
			psmt.setString(3, institude);
			psmt.setInt(4,rating);
			psmt.setString(5, comments);
			
			
			int rows = psmt.executeUpdate();
			System.out.println("Rows affected :-" + rows);
	
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

//		FeedBackService service = new FeedBackService();
//		
//	FeedBack feedback= new FeedBack(code,institude,management,comments,rating);

		//service.insertStaffFeed(feedback);
		
		
		List<FeedBack> staffFeedList = FeedBackDAO.findStaffFeed() ;
		request.setAttribute("SFLIST", staffFeedList);
		RequestDispatcher rd = request.getRequestDispatcher("StaffFeedList.jsp");
		rd.forward(request, response);
	
	}

}