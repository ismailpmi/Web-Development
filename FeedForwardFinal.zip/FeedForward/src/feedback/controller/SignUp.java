package feedback.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import feedback.model.FeedBack;
import feedback.service.FeedBackService;



/**
 * Servlet implementation class SignUp
 */
@WebServlet("/SignUp")
public class SignUp extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int code = Integer.parseInt(request.getParameter("code"));
		String user = request.getParameter("user");
		String username = request.getParameter("username");
		String name = request.getParameter("name");
		String password = request.getParameter("password");
		String email = request.getParameter("email");
		int phone = Integer.parseInt(request.getParameter("phone"));
		
	
	
		

		FeedBackService service = new FeedBackService();
		
		FeedBack feedback= new FeedBack(code,user,username,name,password,email,phone);

		service.insert(feedback);
		
		List<FeedBack> signupList = service.findAll() ;
		request.setAttribute("SIGNUPLIST", signupList);
		RequestDispatcher rd = request.getRequestDispatcher("SignUpList.jsp");
		rd.forward(request, response);

	}
	
}
