create database pmi;
use pmi;



create table users(
   code INT NOT NULL,
   user VARCHAR(100) NOT NULL,
   username VARCHAR(100) NOT NULL,
   name VARCHAR(100) NOT NULL,
   password VARCHAR(12) NOT NULL,
   email VARCHAR(40) NOT NULL,
   phone INT NOT NULL,
   PRIMARY KEY (code)
);

INSERT INTO users( code,user,username,name,password,email,phone)VALUES(1001,"trainee","abdullah","Abdullah P","adu1001","adu@gmail.com",7755662533);
========================================================================
create table staff(
   code INT NOT NULL,
   management VARCHAR(20) NOT NULL,
   institude VARCHAR(100) NOT NULL,
   rating INT NOT NULL,
   comments VARCHAR(40) NOT NULL,
   PRIMARY KEY (code)
);
INSERT INTO staff( code,management,institude,rating,comments)
VALUES(2001,"co-operative","good",8,"well moving");

DELETE FROM tutorials_tbl WHERE tutorial_id=3
======================================================================
create table students(
   code INT NOT NULL,
   course VARCHAR(20) NOT NULL,
   trainner VARCHAR(20) NOT NULL,
   facility VARCHAR(10) NOT NULL,
   status VARCHAR(10) NOT NULL,
   rating INT NOT NULL,
   comments VARCHAR(40) NOT NULL,
   PRIMARY KEY (code)
);
INSERT INTO students( code,course,trainner,facility,status,rating,comments)
VALUES(1001,"JAVA","abdullah","good","completed",8,"Really good");